from setuptools import setup, find_packages

setup(
    name="charity",
    version="0.1.0",
    description="Charity Management App for ERPNext v15",
    author="Your Name",
    author_email="your.email@example.com",
    packages=find_packages(),
    zip_safe=False,
    include_package_data=True,
    install_requires=[
        "frappe>=15.0.0"
    ]
)
