## Running 

Development in browser:

```
$ yarn
$ yarn dev
```

Deploy in iOS simulator (using capacitor):

```
npx yarn build && npx cap run ios -l --external
```