<template>
	<svg
		xmlns="http://www.w3.org/2000/svg"
		x="0px"
		y="0px"
		width="50"
		height="50"
		viewBox="0 0 50 50"
		fill="white"
	>
		<path
			stroke="white"
			stroke-width="1.5"
			d="M44,4H6C4.907,4,4,4.907,4,6v38c0,1.093,0.907,2,2,2h38c1.093,0,2-0.907,2-2V6C46,4.907,45.093,4,44,4z M6,6h38v19H25.977	c-1.103,0-2,0.897-2,2v17H6V6z M42.472,27L25.977,42.671V27H42.472z M27.48,44L44,28.306V44H27.48z"
		></path>
	</svg>
</template>
