<template>
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 26 26" fill="none">
		<path
			d="M13 17C15.7614 17 18 14.7614 18 12C18 9.23858 15.7614 7 13 7C10.2386 7 8 9.23858 8 12C8 14.7614 10.2386 17 13 17Z"
			stroke="currentColor"
			stroke-miterlimit="10"
		/>
		<path
			d="M4.97498 21.9218C5.72824 20.4408 6.87663 19.1971 8.29301 18.3284C9.7094 17.4598 11.3385 17 13.0001 17C14.6616 17 16.2908 17.4598 17.7071 18.3284C19.1235 19.1971 20.2719 20.4407 21.0252 21.9217"
			stroke="currentColor"
			stroke-linecap="round"
			stroke-linejoin="round"
		/>
		<path
			d="M22 6C23.1046 6 24 5.10457 24 4C24 2.89543 23.1046 2 22 2C20.8954 2 20 2.89543 20 4C20 5.10457 20.8954 6 22 6Z"
			stroke="currentColor"
			stroke-linecap="round"
			stroke-linejoin="round"
		/>
		<path
			d="M22 2V0.5"
			stroke="currentColor"
			stroke-linecap="round"
			stroke-linejoin="round"
		/>
		<path
			d="M20.2678 3L18.9688 2.25"
			stroke="currentColor"
			stroke-linecap="round"
			stroke-linejoin="round"
		/>
		<path
			d="M20.2678 5L18.9688 5.75"
			stroke="currentColor"
			stroke-linecap="round"
			stroke-linejoin="round"
		/>
		<path
			d="M22 6V7.5"
			stroke="currentColor"
			stroke-linecap="round"
			stroke-linejoin="round"
		/>
		<path
			d="M23.7328 5L25.0318 5.75"
			stroke="currentColor"
			stroke-linecap="round"
			stroke-linejoin="round"
		/>
		<path
			d="M23.7328 3L25.0318 2.25"
			stroke="currentColor"
			stroke-linecap="round"
			stroke-linejoin="round"
		/>
		<path
			d="M24.9148 11.5625C24.9717 12.0396 25.0001 12.5196 25 13C25 15.3734 24.2962 17.6935 22.9776 19.6668C21.6591 21.6402 19.7849 23.1783 17.5922 24.0866C15.3995 24.9948 12.9867 25.2324 10.6589 24.7694C8.33115 24.3064 6.19295 23.1635 4.51472 21.4853C2.83649 19.8071 1.6936 17.6689 1.23058 15.3411C0.767559 13.0133 1.0052 10.6005 1.91345 8.4078C2.8217 6.21509 4.35977 4.34094 6.33316 3.02236C8.30655 1.70379 10.6266 1 13 1C13.3755 1 13.7467 1.01699 14.1136 1.05098"
			stroke="currentColor"
			stroke-linecap="round"
			stroke-linejoin="round"
		/>
	</svg>
</template>
