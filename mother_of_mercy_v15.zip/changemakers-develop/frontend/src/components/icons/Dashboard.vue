<template>
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 26" fill="none">
		<path
			d="M7.60001 1H1.60001C1.04772 1 0.600006 1.44772 0.600006 2V12.8C0.600006 13.3523 1.04772 13.8 1.60001 13.8H7.60001C8.15229 13.8 8.60001 13.3523 8.60001 12.8V2C8.60001 1.44772 8.15229 1 7.60001 1Z"
			stroke="currentColor"
			stroke-linecap="round"
			stroke-linejoin="round"
		/>
		<path
			d="M7.60001 18.6H1.60001C1.04772 18.6 0.600006 19.0477 0.600006 19.6V24C0.600006 24.5523 1.04772 25 1.60001 25H7.60001C8.15229 25 8.60001 24.5523 8.60001 24V19.6C8.60001 19.0477 8.15229 18.6 7.60001 18.6Z"
			stroke="currentColor"
			stroke-linecap="round"
			stroke-linejoin="round"
		/>
		<path
			d="M20.4 1H14.4C13.8477 1 13.4 1.44772 13.4 2V8C13.4 8.55228 13.8477 9 14.4 9H20.4C20.9523 9 21.4 8.55228 21.4 8V2C21.4 1.44772 20.9523 1 20.4 1Z"
			stroke="currentColor"
			stroke-linecap="round"
			stroke-linejoin="round"
		/>
		<path
			d="M20.4 13.8H14.4C13.8477 13.8 13.4 14.2477 13.4 14.8V24C13.4 24.5523 13.8477 25 14.4 25H20.4C20.9523 25 21.4 24.5523 21.4 24V14.8C21.4 14.2477 20.9523 13.8 20.4 13.8Z"
			stroke="currentColor"
			stroke-linecap="round"
			stroke-linejoin="round"
		/>
	</svg>
</template>
