<template>
	<FeatherIcon name="chevron-left" />
</template>

<script lang="ts" setup>
import { FeatherIcon } from "frappe-ui"
</script>
