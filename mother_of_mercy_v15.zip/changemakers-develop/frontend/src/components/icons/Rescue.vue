<template>
	<svg
		width="25"
		height="24"
		viewBox="0 0 25 24"
		fill="none"
		xmlns="http://www.w3.org/2000/svg"
	>
		<path
			d="M8.22728 6.27273V4C8.22728 3.44771 8.67499 3 9.22728 3H15.7727C16.325 3 16.7727 3.44772 16.7727 4V6.27273"
			stroke="currentColor"
			stroke-miterlimit="10"
			stroke-linecap="square"
		/>
		<path
			d="M20.5 6.27271H4.5C3.94772 6.27271 3.5 6.72042 3.5 7.27271V20C3.5 20.5523 3.94772 21 4.5 21H20.5C21.0523 21 21.5 20.5523 21.5 20V7.27271C21.5 6.72042 21.0523 6.27271 20.5 6.27271Z"
			stroke="currentColor"
			stroke-miterlimit="10"
			stroke-linecap="square"
		/>
		<path
			d="M16.5909 12H14.1364V9.54541H10.8636V12H8.40909V15.2727H10.8636V17.7272H14.1364V15.2727H16.5909V12Z"
			stroke="currentColor"
			stroke-miterlimit="10"
			stroke-linecap="square"
			stroke-linejoin="round"
		/>
	</svg>
</template>
