// Copyright (c) 2023, hussain@frappe.io and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Languages Known", {
// 	refresh(frm) {

// 	},
// });
