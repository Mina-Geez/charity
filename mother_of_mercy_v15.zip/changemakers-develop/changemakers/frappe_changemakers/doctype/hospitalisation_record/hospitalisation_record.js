// Copyright (c) 2022, hussain@frappe.io and contributors
// For license information, please see license.txt

frappe.ui.form.on("Hospitalisation Record", {
	// refresh: function(frm) {
	// }
	bottom_save_button: (frm) => {
		frm.save();
	},
});
