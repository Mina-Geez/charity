# Copyright (c) 2022, hussain@frappe.io and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class CaseFollowup(Document):
	pass
