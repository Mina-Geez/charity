from frappe import _


def get_data():
	return [
		{
			"module_name": "Frappe Changemakers",
			"type": "module",
			"label": _("Frappe Changemakers"),
		}
	]
